

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class Excercise46Test.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class Excercise46Test
{
    private Auction auction1;
    private Lot lot1;
    private Lot lot2;
    private Person person1;
    private Person person2;
    private Bid bid1;
    private Bid bid2;

    /**
     * Default constructor for test class Excercise46Test
     */
    public Excercise46Test()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        auction1 = new Auction();
        lot1 = new Lot(23, "Car");
        lot2 = new Lot(24, "Charger");
        person1 = new Person("Swagdy");
        person2 = new Person("Thomas");
        bid1 = new Bid(person1, 5000);
        bid2 = new Bid(person2, 20);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
