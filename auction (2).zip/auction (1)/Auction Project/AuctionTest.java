import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AuctionTest
{
    private Auction auction1;
    private Person person1;
    private Person person2;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        System.out.print("\f");
        auction1 = new Auction();
        auction1.enterLot("boat");
        auction1.enterLot("artwork");
        auction1.enterLot("house");
        auction1.enterLot("diamond");
        auction1.enterLot("elephant");
        auction1.enterLot("ferrari");
        person1 = new Person("Tisha");
        person2 = new Person("Bill");
        auction1.makeABid(1, person1, 50000);
        auction1.makeABid(4, person1, 2000);
        auction1.makeABid(4, person2, 1999);
        auction1.showLots();
    }
}
